--i

select * from customers;
select * from orders;
select * from products;





CREATE OR REPLACE TYPE ADDRESS as OBJECT(
     City VARCHAR(50),
     Street VARCHAR(100),
     Num NUMBER
     
     
    
);
drop type ADDRESS FORCE;
ALTER TABLE Customers
ADD address address;




UPDATE Customers
SET address = address(
    CASE WHEN DBMS_RANDOM.VALUE <= 0.5 THEN 'Athens'
         WHEN DBMS_RANDOM.VALUE <= 0.6 THEN 'Thessaloniki'
         WHEN DBMS_RANDOM.VALUE <= 0.7 THEN 'Patras'
         WHEN DBMS_RANDOM.VALUE <= 0.8 THEN 'Heraklion'
         WHEN DBMS_RANDOM.VALUE <= 0.9 THEN 'Larissa'
         ELSE 'Volos'
    END,
    CASE WHEN DBMS_RANDOM.VALUE <= 0.1 THEN 'Adrianou Street'
         WHEN DBMS_RANDOM.VALUE <= 0.2 THEN 'Athinas Street'
         WHEN DBMS_RANDOM.VALUE <= 0.3 THEN 'Ermou Street'
         WHEN DBMS_RANDOM.VALUE <= 0.4 THEN 'Panepistimiou Avenue'
         WHEN DBMS_RANDOM.VALUE <= 0.5 THEN 'Patision Street'
         WHEN DBMS_RANDOM.VALUE <= 0.6 THEN 'Vasilissis Sofias Avenue'
         WHEN DBMS_RANDOM.VALUE <= 0.7 THEN 'Kifisias Avenue'
         WHEN DBMS_RANDOM.VALUE <= 0.8 THEN 'Syngrou Avenue'
         WHEN DBMS_RANDOM.VALUE <= 0.9 THEN 'Vouliagmenis Avenue'
         ELSE 'Stadiou Street'
    END,
    TRUNC(DBMS_RANDOM.VALUE * 100) + 1
);

SELECT * FROM CUSTOMERS;

SELECT
    customer_id,
    gender,
    agegroup,
    marital_status,
    income_level,
    TREAT(address AS ADDRESS).City AS City,
    TREAT(address AS ADDRESS).Street AS Street,
    TREAT(address AS ADDRESS).Num AS Num
FROM Customers;
















--ii
select * from products;


CREATE TYPE ProductTypeList AS TABLE OF VARCHAR2(255);
CREATE OR REPLACE TYPE ProductTypeList AS TABLE OF VARCHAR2(255);

ALTER TABLE Products
ADD ProductTypes ProductTypeList
NESTED TABLE ProductTypes STORE AS ProductTypes_storage;

DECLARE
    v_ProductTypes ProductTypeList;
BEGIN
    v_ProductTypes := ProductTypeList('video', 'audio', 'storage', 'games', 'computer', 'other');
END;
/


--iii
CREATE OR REPLACE FUNCTION mapToProductTypes(p_CategoryName IN VARCHAR2)
RETURN ProductTypeList
IS
    v_ProductTypes ProductTypeList := ProductTypeList();
BEGIN
    CASE
        WHEN p_CategoryName LIKE 'Recordable DVD Discs%' OR
             p_CategoryName LIKE 'Camcorders%' OR
             p_CategoryName LIKE 'Camera Batteries%' OR
             p_CategoryName LIKE 'Camera Media%' OR
             p_CategoryName LIKE 'Cameras%' THEN
            v_ProductTypes := ProductTypeList('video');

        WHEN p_CategoryName LIKE 'CD-ROM%' OR
             p_CategoryName LIKE 'Home Audio%' THEN
            v_ProductTypes := ProductTypeList('audio');

        WHEN p_CategoryName LIKE 'CD-ROM%' OR
             p_CategoryName LIKE 'Recordable DVD Discs%' OR
             p_CategoryName LIKE 'Bulk Pack Diskettes%' OR
             p_CategoryName LIKE 'Recordable CDs%' OR
             p_CategoryName LIKE 'Memory%' THEN
            v_ProductTypes := ProductTypeList('storage');

        WHEN p_CategoryName LIKE 'CD-ROM%' OR
             p_CategoryName LIKE 'Recordable DVD Discs%' OR
             p_CategoryName LIKE 'Game Consoles%' OR
             p_CategoryName LIKE 'Y Box Games%' OR
             p_CategoryName LIKE 'Y Box Accessories%' THEN
            v_ProductTypes := ProductTypeList('games');

        WHEN p_CategoryName LIKE 'Modems/Fax%' OR
             p_CategoryName LIKE 'Accessories%' OR
             p_CategoryName LIKE 'Desktop PCs%' OR
             p_CategoryName LIKE 'Memory%' OR
             p_CategoryName LIKE 'Operating Systems%' OR
             p_CategoryName LIKE 'Monitors%' OR
             p_CategoryName LIKE 'Portable PCs%' THEN
            v_ProductTypes := ProductTypeList('computer');

        WHEN p_CategoryName LIKE 'Documentation%' OR
             p_CategoryName LIKE 'Modems/Fax%' OR
             p_CategoryName LIKE 'Printer Supplies%' OR
             p_CategoryName LIKE 'Accessories%' THEN
            v_ProductTypes := ProductTypeList('other');

        ELSE
            v_ProductTypes := ProductTypeList('other');
    END CASE;

    RETURN v_ProductTypes;
END;
/


UPDATE Products
SET ProductTypes = mapToProductTypes(Category_Name);



--iv


select * from orders;
CREATE OR REPLACE TYPE ProductType AS OBJECT (
    product_id INT,
    productname VARCHAR2(100),
    categoryname VARCHAR2(100),
    producttypes ProductTypeList,
    listprice NUMBER
);
/

CREATE OR REPLACE TYPE OrderItemType AS OBJECT (
    days_to_process INT,
    price NUMBER,
    cost NUMBER,
    channel VARCHAR2(50),
    product ProductType
);
/

CREATE OR REPLACE TYPE OrderItemArrayType IS TABLE OF OrderItemType;
/

CREATE OR REPLACE PACKAGE OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    );
END OrderPackage;
/

CREATE OR REPLACE PACKAGE BODY OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    ) IS
    BEGIN
        --Ypothesi oti thelo na kano retried ena customer_id
        SELECT customer_id
        INTO p_customer_id
        FROM orders
        WHERE order_id = p_order_id;

        -- ...
    END GetOrderDetails;
END OrderPackage;
/



--v




CREATE OR REPLACE PACKAGE OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    );

    FUNCTION CalculateOrderProfit(p_order_id IN INT) RETURN NUMBER;
END OrderPackage;
/



CREATE OR REPLACE PACKAGE OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    );

    FUNCTION CalculateOrderProfit(p_order_id IN INT) RETURN NUMBER;
END OrderPackage;
/




CREATE OR REPLACE PACKAGE BODY OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    ) IS
    BEGIN
        -- ypothetoume oti theloyme na kanoyme retrieve ena customer_id apo orders table
        SELECT customer_id
        INTO p_customer_id
        FROM orders
        WHERE order_id = p_order_id;

      
        -- 
        p_order_items := OrderItemArrayType(
            OrderItemType(days_to_process => 1, price => 100, cost => 50, channel => 'Online', product => null), -- Replace with actual values
            OrderItemType(days_to_process => 2, price => 150, cost => 70, channel => 'In-Store', product => null) -- Replace with actual values
           
        );
    END GetOrderDetails;

    FUNCTION CalculateOrderProfit(p_order_id IN INT) RETURN NUMBER IS
        v_total_profit NUMBER := 0;

        -- 
        CURSOR order_items_cur IS
            SELECT price, cost
            FROM orders
            WHERE order_id = p_order_id;

        -- 
        v_order_item order_items_cur%ROWTYPE;

    BEGIN
        OPEN order_items_cur;
        LOOP
            FETCH order_items_cur INTO v_order_item;
            EXIT WHEN order_items_cur%NOTFOUND;

            -- Calculate profit for each order item
            v_total_profit := v_total_profit + (v_order_item.price - v_order_item.cost);
        END LOOP;
        CLOSE order_items_cur;

        RETURN v_total_profit;
    END CalculateOrderProfit;
END OrderPackage;
/


--gia na testaro oti fernei to final profit tin paraggelias me id: 12316

SET SERVEROUTPUT ON;
DECLARE
    v_order_id INT := 12316; -- 
    v_final_profit NUMBER;
BEGIN
    v_final_profit := OrderPackage.CalculateOrderProfit(v_order_id);
    DBMS_OUTPUT.PUT_LINE('Final Profit for Order ' || v_order_id || ': ' || v_final_profit);
END;
/


--vi 



CREATE OR REPLACE PACKAGE OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    );

    FUNCTION CalculateOrderProfit(p_order_id IN INT) RETURN NUMBER;

    FUNCTION MergeAndCalculateTotalProfit(
        p_existing_order_id IN INT,
        p_new_order_id IN INT
    ) RETURN NUMBER;
END OrderPackage;
/


CREATE OR REPLACE PACKAGE OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    );

    FUNCTION CalculateOrderProfit(p_order_id IN INT) RETURN NUMBER;

    FUNCTION MergeAndCalculateTotalProfit(
        p_existing_order_id IN INT,
        p_new_order_id IN INT
    ) RETURN NUMBER;
END OrderPackage;
/

CREATE OR REPLACE PACKAGE BODY OrderPackage AS
    PROCEDURE GetOrderDetails(
        p_order_id IN INT,
        p_customer_id OUT INT,
        p_order_items OUT OrderItemArrayType
    ) IS
    BEGIN
        -- 
        SELECT customer_id
        INTO p_customer_id
        FROM orders
        WHERE order_id = p_order_id;

      
        p_order_items := OrderItemArrayType(
            OrderItemType(days_to_process => 1, price => 100, cost => 50, channel => 'Online', product => null), -- Replace with actual values
            OrderItemType(days_to_process => 2, price => 150, cost => 70, channel => 'In-Store', product => null) -- Replace with actual values
            
        );
    END GetOrderDetails;

    FUNCTION CalculateOrderProfit(p_order_id IN INT) RETURN NUMBER IS
        v_total_profit NUMBER := 0;

        --
        CURSOR order_items_cur IS
            SELECT price, cost
            FROM orders
            WHERE order_id = p_order_id;

        -- 
        v_order_item order_items_cur%ROWTYPE;

    BEGIN
        OPEN order_items_cur;
        LOOP
            FETCH order_items_cur INTO v_order_item;
            EXIT WHEN order_items_cur%NOTFOUND;

            -- Ypologismos profit gia kathe item
            v_total_profit := v_total_profit + (v_order_item.price - v_order_item.cost);
        END LOOP;
        CLOSE order_items_cur;

        RETURN v_total_profit;
    END CalculateOrderProfit;

    FUNCTION MergeAndCalculateTotalProfit(
        p_existing_order_id IN INT,
        p_new_order_id IN INT
    ) RETURN NUMBER IS
        v_existing_total_profit NUMBER;
        v_new_order_total_profit NUMBER;
        v_final_total_profit NUMBER;

    BEGIN
        -- Calculate total profit gia iparxoysa(Existing) order
        v_existing_total_profit := CalculateOrderProfit(p_existing_order_id);

        -- Calculate total profit for the new order
        v_new_order_total_profit := CalculateOrderProfit(p_new_order_id);

        -- Merge the total profits
        v_final_total_profit := v_existing_total_profit + v_new_order_total_profit;

        RETURN v_final_total_profit;
    END MergeAndCalculateTotalProfit;
END OrderPackage;
/




--to test it
DECLARE
    v_existing_order_id INT := 12316; -- 
    v_new_order_id INT := 3953;      -- 
    v_final_total_profit NUMBER;
BEGIN
    -- Kaloume  MergeAndCalculateTotalProfit function
    v_final_total_profit := OrderPackage.MergeAndCalculateTotalProfit(v_existing_order_id, v_new_order_id);

    -- Display the result
    DBMS_OUTPUT.PUT_LINE('Final Total Profit: ' || v_final_total_profit);
END;
/







--vii
--ignore
CREATE OR REPLACE TYPE ClientInfoType AS OBJECT (
    customer_id INT,
    address_str VARCHAR2(200),
    products_delivered INT,
    total_profit NUMBER
);
/
DROP TYPE ClientInfoType FORCE;
-- ignore
CREATE OR REPLACE TYPE ClientInfoArrayType AS TABLE OF ClientInfoType;
/







-- einai hdh ftiagmeno apo erotima 1
CREATE OR REPLACE TYPE ADDRESS AS OBJECT (
    City VARCHAR(50),
    Street VARCHAR(100),
    Num NUMBER
);

DROP TYPE Address FORCE;







--procedute gia tracking ton pelaton vasei dieythinsis
CREATE OR REPLACE PROCEDURE TrackClientsByAddress(
    p_city IN VARCHAR2,
    p_street IN VARCHAR2,
    p_num_start IN NUMBER,
    p_num_end IN NUMBER,
    p_clients OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN p_clients FOR
        SELECT 
            c.customer_id,
            TREAT(c.address AS ADDRESS).City || ', ' || TREAT(c.address AS ADDRESS).Street || ', ' || TREAT(c.address AS ADDRESS).Num AS address_str,
            COUNT(DISTINCT o.product_id) AS total_products,
            -- 
            SUM(o.price - o.cost) AS total_profit
        FROM 
            Customers c
        LEFT JOIN 
            orders o ON c.customer_id = o.customer_id
        WHERE 
            TREAT(c.address AS ADDRESS).City = p_city
            AND TREAT(c.address AS ADDRESS).Street = p_street
            AND TREAT(c.address AS ADDRESS).Num BETWEEN p_num_start AND p_num_end
        GROUP BY 
            c.customer_id, TREAT(c.address AS ADDRESS).City, TREAT(c.address AS ADDRESS).Street, TREAT(c.address AS ADDRESS).Num;
END TrackClientsByAddress;
/


-- 
SELECT
    customer_id,
    gender,
    agegroup,
    marital_status,
    income_level,
    TREAT(address AS ADDRESS).City AS City,
    TREAT(address AS ADDRESS).Street AS Street,
    TREAT(address AS ADDRESS).Num AS Num
FROM Customers;




--for testing

DECLARE
    v_clients SYS_REFCURSOR;
    v_customer_id NUMBER;  -- Declare the variables here
    v_address VARCHAR2(150);
    v_total_products NUMBER;
    v_total_profit NUMBER;
BEGIN
    TrackClientsByAddress('Athens', 'Panepistimiou Avenue', 1, 100, v_clients);

    DBMS_OUTPUT.PUT_LINE('Customer_ID | Address | Total_Products | Total_Profit');
    DBMS_OUTPUT.PUT_LINE('-----------------------------------------------');

    LOOP
        FETCH v_clients INTO
            v_customer_id,
            v_address,
            v_total_products,
            v_total_profit;

        EXIT WHEN v_clients%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE(v_customer_id || ' | ' || v_address || ' | ' || v_total_products || ' | ' || v_total_profit);
    END LOOP;

    CLOSE v_clients;
END;
/


--kati egine me to compile gia ayto to ebala
ALTER PROCEDURE IT2021154.TRACKCLIENTSBYADDRESS COMPILE;


--dimiourgia pinaka episis gia na kataxoreite kai se pinaka
CREATE TABLE ClientInfoType(

    CUSTOMER_ID NUMBER,
    ADDRESS VARCHAR(250),
    PRODUCTS_AMOUNT NUMBER,
    TOTAL_PROFIT NUMBER
    


);


--edo testaroume gia na doyme kataxorimena ta values poy exoyme orisei

DECLARE
    v_clients SYS_REFCURSOR;
    v_customer_id NUMBER;  -- Declare the variables here
    v_address VARCHAR2(150);
    v_total_products NUMBER;
    v_total_profit NUMBER;
BEGIN
    TrackClientsByAddress('Athens', 'Panepistimiou Avenue', 1, 100, v_clients);

    DBMS_OUTPUT.PUT_LINE('Customer_ID | Address | Total_Products | Total_Profit');
    DBMS_OUTPUT.PUT_LINE('-----------------------------------------------');

    LOOP
        FETCH v_clients INTO
            v_customer_id,
            v_address,
            v_total_products,
            v_total_profit;

        EXIT WHEN v_clients%NOTFOUND;

        -- Display the results
        DBMS_OUTPUT.PUT_LINE(v_customer_id || ' | ' || v_address || ' | ' || v_total_products || ' | ' || v_total_profit);

        -- Insert into the ClientInfoType table
        INSERT INTO ClientInfoType (CUSTOMER_ID, ADDRESS, PRODUCTS_AMOUNT, TOTAL_PROFIT)
        VALUES (v_customer_id, v_address, v_total_products, v_total_profit);
    END LOOP;

    CLOSE v_clients;
END;
/

-- edo einai to table me ta values poy valame 
select * from ClientInfoType;


--Erotima 2o
--ignore gia testing
select * from customers
;
select * from products;
select count(product_id) from products where category_name LIKE 'Camera Batteries%';

select * from orders;


SELECT XMLElement("products",
XMLAgg(
XMLElement("product",
XMLForest(product_id AS "id",
PRODUCT_NAME AS "name",
category_name AS "category")
)
)
).getClobVal() AS xml_output
FROM products;






--without address type and producttype list
--diarkei peripoy 21-23 deuterolepta gia na treksei
SELECT
    XMLELEMENT("customers",
        XMLAGG(
            XMLELEMENT("customer",
                XMLFOREST(
                    c.customer_id AS "id",
                    c.gender AS "Gender",
                    c.marital_status AS "MaritalStatus",
                    c.agegroup AS "AgeGroup",
                    c.income_level AS "IncomeLevel",
                    XMLELEMENT("Products",
                        XMLAGG(
                            XMLELEMENT("Product",
                                XMLFOREST(
                                    o.product_id AS "id",
                                    p.product_name AS "ProductName",
                                    p.category_name AS "ProductCategory"
                                )
                            )
                        )
                    ) AS "Products"
                )
            )
        )
    ).getClobVal() AS xml_output
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN products p ON o.product_id = p.product_id
WHERE o.days_to_process <= 20
GROUP BY c.customer_id, c.gender, c.marital_status, c.agegroup, c.income_level;





--edo einai to erotima 2o
--me address type kai producttype 
--diarkei peripoy 33-35 deuterolepta gia na treksei

SELECT
    XMLElement(
        "customers",
        XMLAgg(
            XMLElement(
                "customer",
                XMLAttributes(
                    c.customer_id AS "id",
                    c.gender AS "Gender",
                    c.marital_status AS "MaritalStatus"
                ),
                XMLElement("AgeGroup", c.agegroup),
                XMLElement("IncomeLevel", c.income_level),
                XMLElement(
                    "Address",
                    XMLForest(
                        TREAT(c.address AS ADDRESS).City AS "City",
                        TREAT(c.address AS ADDRESS).Street AS "Street",
                        TREAT(c.address AS ADDRESS).Num AS "Number"
                    )
                ),
                XMLElement(
                    "Products",
                    XMLAgg(
                        XMLElement(
                            "Product",
                            XMLAttributes(
                                p.product_id AS "id"
                            ),
                            XMLElement("ProductName", p.product_name),
                            XMLElement("ProductCategory", p.category_name),
                            XMLElement(
                                "ProductTypes",
                                (SELECT
                                    XMLAgg(
                                        XMLElement("ProductType", pt.COLUMN_VALUE)
                                    )
                                FROM
                                    TABLE(CAST(p.producttypes AS ProductTypeList)) pt
                                )
                            )
                        )
                    )
                )
            )
        )
    ).getClobVal() AS xml_data
FROM
    customers c
JOIN
    orders o ON c.customer_id = o.customer_id
JOIN
    products p ON o.product_id = p.product_id
WHERE
    o.days_to_process <= 20
GROUP BY
    c.customer_id, c.gender, c.marital_status, c.agegroup, c.income_level, TREAT(c.address AS ADDRESS).City, TREAT(c.address AS ADDRESS).Street, TREAT(c.address AS ADDRESS).Num;



--edo einai to erotima 2o gia distinct products
-- prosthiki to query gia distinct products (������ ��������)
SELECT
    XMLElement(
        "customers",
        XMLAgg(
            XMLElement(
                "customer",
                XMLAttributes(
                    c.customer_id AS "id",
                    c.gender AS "Gender",
                    c.marital_status AS "MaritalStatus"
                ),
                XMLElement("AgeGroup", c.agegroup),
                XMLElement("IncomeLevel", c.income_level),
                XMLElement(
                    "Address",
                    XMLForest(
                        TREAT(c.address AS ADDRESS).City AS "City",
                        TREAT(c.address AS ADDRESS).Street AS "Street",
                        TREAT(c.address AS ADDRESS).Num AS "Number"
                    )
                ),
                XMLElement(
                    "Products",
                    XMLAgg(
                        XMLElement(
                            "Product",
                            XMLAttributes(
                                p.product_id AS "id"
                            ),
                            XMLElement("ProductName", p.product_name),
                            XMLElement("ProductCategory", p.category_name),
                            XMLElement(
                                "ProductTypes",
                                (SELECT
                                    XMLAgg(
                                        XMLElement("ProductType", pt.COLUMN_VALUE)
                                    )
                                FROM
                                    (SELECT DISTINCT COLUMN_VALUE FROM TABLE(CAST(p.producttypes AS ProductTypeList))) pt
                                )
                            )
                        )
                    )
                )
            )
        )
    ).getClobVal() AS xml_data
FROM
    customers c
JOIN
    orders o ON c.customer_id = o.customer_id
JOIN
    products p ON o.product_id = p.product_id
WHERE
    o.days_to_process <= 20
GROUP BY
    c.customer_id, c.gender, c.marital_status, c.agegroup, c.income_level, TREAT(c.address AS ADDRESS).City, TREAT(c.address AS ADDRESS).Street, TREAT(c.address AS ADDRESS).Num;


--Erotima 3o

--gia na min to kano manually gia na paro touw protous 30 epeidh to proigoumeno eksagei para polous perlates 
-- sto proigoumeno query: prosthesa ena ROWNUM STO WHERE clause moy gia na moy ferei tous top 30 pelates kai ORDER BY gia customer_id
-- ousiastika vazo oria sta results moy na einai 30.

SELECT
    XMLElement(
        "customers",
        XMLAgg(
            XMLElement(
                "customer",
                XMLAttributes(
                    c.customer_id AS "id",
                    c.gender AS "Gender",
                    c.marital_status AS "MaritalStatus"
                ),
                XMLElement("AgeGroup", c.agegroup),
                XMLElement("IncomeLevel", c.income_level),
                XMLElement(
                    "Address",
                    XMLForest(
                        TREAT(c.address AS ADDRESS).City AS "City",
                        TREAT(c.address AS ADDRESS).Street AS "Street",
                        TREAT(c.address AS ADDRESS).Num AS "Number"
                    )
                ),
                XMLElement(
                    "Products",
                    XMLAgg(
                        XMLElement(
                            "Product",
                            XMLAttributes(
                                p.product_id AS "id"
                            ),
                            XMLElement("ProductName", p.product_name),
                            XMLElement("ProductCategory", p.category_name),
                            XMLElement(
                                "ProductTypes",
                                (SELECT
                                    XMLAgg(
                                        XMLElement("ProductType", pt.COLUMN_VALUE)
                                    )
                                FROM
                                    (SELECT DISTINCT COLUMN_VALUE FROM TABLE(CAST(p.producttypes AS ProductTypeList))) pt
                                )
                            )
                        )
                    )
                )
            )
        )
    ).getClobVal() AS xml_data
FROM
    customers c
JOIN
    orders o ON c.customer_id = o.customer_id
JOIN
    products p ON o.product_id = p.product_id
WHERE
    o.days_to_process <= 20
    AND ROWNUM <= 30
GROUP BY
    c.customer_id, c.gender, c.marital_status, c.agegroup, c.income_level, TREAT(c.address AS ADDRESS).City, TREAT(c.address AS ADDRESS).Street, TREAT(c.address AS ADDRESS).Num
ORDER BY
    c.customer_id;



-- proto ipoerotima 3ou erotimatos

--Den eixe stouw protous 30 poy evala Monitors gia auto ekane no match : 
//customer[@Gender='Male' and AgeGroup='above 70' and Products/Product/ProductCategory='Monitors']/@id

--alla evala katigoria proiontos Camera Batteries kai evgale to results ton customer_id poy to exoyn
//customer[@Gender='Male' and AgeGroup='above 70' and Products/Product/ProductCategory='Camera Batteries']/@id



--deutero ipoerotima 3ou erotimatos
--pali stous protous 30 den eixa ginaikes me games alla eixa video
//customer[@Gender='Female' and Products/Product/ProductTypes/ProductType[contains(., 'video')]]/Products/Product/ProductCategory


--trito ipoerotima 3ou erotimatos
--den eixa kapoion kai itan no match gia odo ermou alla eida Thessaloniki me allo Steet gia na to testaro 
--afino kai tis 2 entoles 
--i proti bgazei apla no match kai i deuteri ta customer_id auton poy antistoixoyn

//customer[IncomeLevel='high' and Address/City='Volos' and Address/Street='Ermou Street']/Products/Product/ProductTypes/ProductType


//customer[IncomeLevel='high' and Address/City='Thessaloniki' and Address/Street='Athinas Street']/Products/Product/ProductTypes/ProductType